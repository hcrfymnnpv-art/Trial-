# Ocean Captain 3D — iPhone prototype

This is a browser-playable 3D cargo ship simulator prototype.

Open `index.html` in a modern browser with internet access (it loads Three.js from a CDN).
On iPhone, the easiest route is to upload the file to a simple static web host and open the resulting link in Safari.

Controls:
- THROTTLE: accelerate
- REVERSE: slow down / reverse
- ◀ / ▶: rudder
- Sail to the yellow ring at the port and stop to deliver cargo.

Next build can add a larger world, better ship model, waves, weather, multiple ports, cargo contracts, AI traffic, docking camera and save/progression.
